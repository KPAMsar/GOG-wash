<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('sbadmin/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('sbadmin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('sbadmin/js/sb-admin-2.min.js')); ?>"></script>



<?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/_includes/foot.blade.php ENDPATH**/ ?>