<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session()->has('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>


    <div>
        <div>
            <h5 class="dashboard-wel text-center" >Profile</h5>

        </div>
    </div>

	<div class="row">
		<div class="col-xl-1 col-md- ">

		</div>
		<div class="col-xl-9 col-md-12 ">
        <div class="card border-left-prima shadow h-100 py-2 cab-1">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="text-xs font-weight-bold dashboard-danger text-uppercase mb-1">


						</div>

                        <div class="text-center">
                        <!-- <img src="assets/images/logo/kpam.jpg" class="rounded profile-img" alt="..."> -->
                        </div>

                                    <div class="col-md-8">
                                    <div class="card-body">



                                    </div>
                                    </div>

                                </div>
                        </div>

                        <div class="card" style="width: 45rem;">
                        <div class="card-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-9 col-sm-6">
                                    <h5 class="dashboard-wel">Data </h5>
                                    </div>
                                    <div class="col-md-3 col-sm-6">
                                    <a href="<?php echo e(url('client/edit-profile/'.Auth::user()-> id)); ?>" class="btn btn-primary">Update profile</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-9 col-sm-6">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"> <h5 class="profile-wel">First Name:<?php echo e(Auth::user()->firstname); ?> </h5></li>
                            <li class="list-group-item"><h5 class="profile-wel">Lastname:<?php echo e(Auth::user()->lastname); ?></h5></li>
                            <li class="list-group-item"><h5 class="profile-wel">Email:<?php echo e(Auth::user()->email); ?></h5></li>
                            <li class="list-group-item"><h5 class="profile-wel"><h5 class="profile-wel">Phone number:<?php echo e(Auth::user()->phone); ?></h5></li>
                            <li class="list-group-item"><h5 class="profile-wel"><h5 class="profile-wel">Address:<?php echo e(Auth::user()->address); ?></h5></li>
                            <!-- <li class="list-group-item"><h5 class="profile-wel"> <h5 class="profile-wel">Referal Code:GOG001</h5></li> -->
                        </ul>
                         </div>

                        <br>
                    </div>











        </div>











    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.account.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/client/profile.blade.php ENDPATH**/ ?>