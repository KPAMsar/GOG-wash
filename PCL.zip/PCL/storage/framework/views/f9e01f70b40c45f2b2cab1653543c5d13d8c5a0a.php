




<!DOCTYPE html>
<html lang="en">

<head>

  <title>Login</title>

  <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <div class="p-5">
              <div class="text-center">
              <div class="card-header"><?php echo e(__('Reset Password')); ?></div>
              </div>

              <form class="user" action="<?php echo e(route('password.email')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(session()->has('error')): ?>
                  <div class="alert alert-danger alert-dismissible">
                    <span><?php echo e(session('error' )); ?></span>
                    <button class="close" data-dismiss="alert">&times;</button>
                  </div>
                <?php endif; ?>

                <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn " style="background-color:#063464  ; color:white;">
                                    <?php echo e(__('Send Password Reset Link')); ?>

                                </button>
                            </div>
                </div><br><br><br>




              </form>

            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <?php echo $__env->make('_includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>