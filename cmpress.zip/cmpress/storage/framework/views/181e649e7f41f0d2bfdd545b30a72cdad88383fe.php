



<!DOCTYPE html>
<html lang="en">

<head>

  <title>Login</title>

  <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-gradient-primary">
<!-- <div class="row justify-content-center">

<img src="<?php echo e(url('assets/images/logo/logo2.png')); ?>" style="width:15%; height:15%;">
</div> -->


  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Welcome</h1>
              </div>

              <form class="user" action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(session()->has('error')): ?>
                  <div class="alert alert-danger alert-dismissible">
                    <span><?php echo e(session('error' )); ?></span>
                    <button class="close" data-dismiss="alert">&times;</button>
                  </div>
                <?php endif; ?>
                <div class="form-group">
                  <input type="email" class="form-control form-control-user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" name="email" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Email" autofocus>

                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="exampleInputPassword" placeholder="Password">

                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <div class="custom-control custom-checkbox small">
                    <input type="checkbox" class="custom-control-input" id="customCheck" name="remember">
                    <label class="custom-control-label" for="customCheck">Remember Me</label>
                  </div>
                </div>
                <button type="submit" style="background-color:#063464; color:white;" class="btn  btn-user btn-block">
                  Login
                </button><br><br><br>

                <div class="container">
                    <div class="row">
                        <div class="col-6">
                        <p><a href="<?php echo e(route('register')); ?>" style="color:#063464;">Sign up?</a></p>
                        </div>
                        <div class="col-6">
                        <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>" style="color:#063464;">
                                        <?php echo e(__('Forgot  Password?')); ?>

                                    </a>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>


              </form>

            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <?php echo $__env->make('_includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/auth/login.blade.php ENDPATH**/ ?>