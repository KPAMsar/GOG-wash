<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session()->has('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

    <div>
            <h5 class="dashboard-wel text-center" >Laundry Item</h5>
    </div>

        <div class="container">
        <div class="row">
		<div class=" col-sm-12 ">
        <div class="card border-left-prima shadow h-100 py-2 cab-1">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="text-xs font-weight-bold dashboard-danger text-uppercase mb-1">
                            <div class="row">
                            <div>

                    <div class=" py-2 d-flex align-items-center justify-content-between">
                    <div>
                        <h5 class="dashboard-wel text-center" ></h5>
                    </div>
                        <a href="<?php echo e(route('admin.create-items')); ?>" class="btn btn-sm btn-primary">Add</a>
                    </div>
                    </div>
                    <table id="table_id" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Express Laundry</th>
                        <th>Action</th>

                    </tr>
                </thead>


                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item -> id); ?></td>
                        <td><?php echo e($item -> item); ?></td>
                        <td><?php echo e($item -> price); ?></td>
                        <td><?php echo e($item -> express_laundry); ?></td>

                        <td><a href="<?php echo e(url('admin/edit-items/'.$item->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(url('admin/delete-customers/'.$item->id)); ?>"> <button  class="btn btn-sm btn-danger">

                        <i class="fa fa-trash"></i>
                        </button>
                        </a>

						</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>

            </table>


        <script>
                $(document).ready(function() {
                $("#table_id").dataTable();
                } );
        </script>

	</div>
        </div>



  </div>
</div>
</div>
            </div>





<br><br><br><br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.tables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/laundry-items/index.blade.php ENDPATH**/ ?>