<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright &copy; G.O.G wash</span>
    </div>
  </div>
</footer>
<?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/staff/_partials/footer.blade.php ENDPATH**/ ?>