<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <section class="pricing pricing-1" id="pricing-1">
         <div class="container">
            <div class="row">
               <div class="col-12 col-lg- offset-lg-">
                  <div class="heading heading-8 text-center">
                     <p class="heading-subtitle">Our Pricing And Plans </p>
                     <h2 class="heading-title"> Pricing That Adapts Your Needs</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="">
                  <div class="pricing-table">
                     <div class="">
                        <div class="pricing-body">
                           <div class="pricing-heading">

</div>

                           <div class="table-responsive">
                    <table id="table_id" class="table table-striped table-bordered">
                <thead>
                                     <tr>
                                       <th scope="col">#</th>
                                       <th scope="col">ITEM</th>
                                       <th scope="col">PRICE(NGN)</th>
                                       <th scope="col">EXPRESS LAUNDRY(NGN)</th>
                                    </tr>
                </thead>


                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr >
                    <th scope="row"><?php echo e($item->id); ?></th>
                    <td><?php echo e($item->item); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->express_laundry); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>

            </table>
                    </div>




                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-12 col-lg-6 offset-lg-3">
                     <div class="processes-note">
                        <div class="note-bg"><i class="fimanager flaticon-008-hand"></i></div>
                        <p>A specialized team of qualified specialists is required for a laundry
                          that meets your highest requirements. <a href="<?php echo e(url('contact-us')); ?>">Contact Us For More Information<i class="icon-arrow-right"></i></a>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
      </section>




<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kpam/Desktop/PCL/PCL/resources/views/frontend/pricing.blade.php ENDPATH**/ ?>